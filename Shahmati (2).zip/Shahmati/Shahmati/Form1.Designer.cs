﻿namespace Shahmati
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.BackPanel = new System.Windows.Forms.Panel();
            this.panel25 = new System.Windows.Forms.Panel();
            this.panel17 = new System.Windows.Forms.Panel();
            this.panel26 = new System.Windows.Forms.Panel();
            this.panel27 = new System.Windows.Forms.Panel();
            this.panel16 = new System.Windows.Forms.Panel();
            this.panel28 = new System.Windows.Forms.Panel();
            this.panel15 = new System.Windows.Forms.Panel();
            this.panel29 = new System.Windows.Forms.Panel();
            this.panel24 = new System.Windows.Forms.Panel();
            this.panel30 = new System.Windows.Forms.Panel();
            this.panel18 = new System.Windows.Forms.Panel();
            this.panel31 = new System.Windows.Forms.Panel();
            this.panel14 = new System.Windows.Forms.Panel();
            this.panel32 = new System.Windows.Forms.Panel();
            this.panel23 = new System.Windows.Forms.Panel();
            this.panel13 = new System.Windows.Forms.Panel();
            this.panel22 = new System.Windows.Forms.Panel();
            this.panel12 = new System.Windows.Forms.Panel();
            this.panel19 = new System.Windows.Forms.Panel();
            this.panel11 = new System.Windows.Forms.Panel();
            this.panel21 = new System.Windows.Forms.Panel();
            this.panel10 = new System.Windows.Forms.Panel();
            this.panel20 = new System.Windows.Forms.Panel();
            this.panel9 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel7 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel8 = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.BackPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // BackPanel
            // 
            this.BackPanel.BackColor = System.Drawing.Color.BurlyWood;
            this.BackPanel.BackgroundImage = global::Shahmati.Properties.Resources.Доска1;
            this.BackPanel.Controls.Add(this.panel25);
            this.BackPanel.Controls.Add(this.panel17);
            this.BackPanel.Controls.Add(this.panel26);
            this.BackPanel.Controls.Add(this.panel27);
            this.BackPanel.Controls.Add(this.panel16);
            this.BackPanel.Controls.Add(this.panel28);
            this.BackPanel.Controls.Add(this.panel15);
            this.BackPanel.Controls.Add(this.panel29);
            this.BackPanel.Controls.Add(this.panel24);
            this.BackPanel.Controls.Add(this.panel30);
            this.BackPanel.Controls.Add(this.panel18);
            this.BackPanel.Controls.Add(this.panel31);
            this.BackPanel.Controls.Add(this.panel14);
            this.BackPanel.Controls.Add(this.panel32);
            this.BackPanel.Controls.Add(this.panel23);
            this.BackPanel.Controls.Add(this.panel13);
            this.BackPanel.Controls.Add(this.panel22);
            this.BackPanel.Controls.Add(this.panel12);
            this.BackPanel.Controls.Add(this.panel19);
            this.BackPanel.Controls.Add(this.panel11);
            this.BackPanel.Controls.Add(this.panel21);
            this.BackPanel.Controls.Add(this.panel10);
            this.BackPanel.Controls.Add(this.panel20);
            this.BackPanel.Controls.Add(this.panel9);
            this.BackPanel.Controls.Add(this.panel5);
            this.BackPanel.Controls.Add(this.panel3);
            this.BackPanel.Controls.Add(this.panel6);
            this.BackPanel.Controls.Add(this.panel4);
            this.BackPanel.Controls.Add(this.panel7);
            this.BackPanel.Controls.Add(this.panel2);
            this.BackPanel.Controls.Add(this.panel8);
            this.BackPanel.Controls.Add(this.panel1);
            this.BackPanel.Location = new System.Drawing.Point(10, 10);
            this.BackPanel.Margin = new System.Windows.Forms.Padding(2);
            this.BackPanel.Name = "BackPanel";
            this.BackPanel.Size = new System.Drawing.Size(640, 640);
            this.BackPanel.TabIndex = 0;
            this.BackPanel.MouseClick += new System.Windows.Forms.MouseEventHandler(this.BackPanel_MouseClick);
            // 
            // panel25
            // 
            this.panel25.BackColor = System.Drawing.Color.Transparent;
            this.panel25.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel25.BackgroundImage")));
            this.panel25.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel25.Location = new System.Drawing.Point(560, 80);
            this.panel25.Name = "panel25";
            this.panel25.Size = new System.Drawing.Size(80, 80);
            this.panel25.TabIndex = 15;
            this.panel25.Tag = "black";
            this.panel25.Click += new System.EventHandler(this.panel25_Click);
            // 
            // panel17
            // 
            this.panel17.BackColor = System.Drawing.Color.Transparent;
            this.panel17.BackgroundImage = global::Shahmati.Properties.Resources.Ферзь2;
            this.panel17.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel17.Location = new System.Drawing.Point(240, 0);
            this.panel17.Name = "panel17";
            this.panel17.Size = new System.Drawing.Size(80, 80);
            this.panel17.TabIndex = 13;
            this.panel17.Tag = "black";
            this.panel17.Click += new System.EventHandler(this.panel16_Click);
            // 
            // panel26
            // 
            this.panel26.BackColor = System.Drawing.Color.Transparent;
            this.panel26.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel26.BackgroundImage")));
            this.panel26.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel26.Location = new System.Drawing.Point(240, 80);
            this.panel26.Name = "panel26";
            this.panel26.Size = new System.Drawing.Size(80, 80);
            this.panel26.TabIndex = 11;
            this.panel26.Tag = "black";
            this.panel26.Click += new System.EventHandler(this.panel25_Click);
            // 
            // panel27
            // 
            this.panel27.BackColor = System.Drawing.Color.Transparent;
            this.panel27.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel27.BackgroundImage")));
            this.panel27.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel27.Location = new System.Drawing.Point(480, 80);
            this.panel27.Name = "panel27";
            this.panel27.Size = new System.Drawing.Size(80, 80);
            this.panel27.TabIndex = 14;
            this.panel27.Tag = "black";
            this.panel27.Click += new System.EventHandler(this.panel25_Click);
            // 
            // panel16
            // 
            this.panel16.BackColor = System.Drawing.Color.Transparent;
            this.panel16.BackgroundImage = global::Shahmati.Properties.Resources.Ферзь;
            this.panel16.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel16.Location = new System.Drawing.Point(240, 560);
            this.panel16.Name = "panel16";
            this.panel16.Size = new System.Drawing.Size(80, 80);
            this.panel16.TabIndex = 5;
            this.panel16.Tag = "white";
            this.panel16.Click += new System.EventHandler(this.panel16_Click);
            // 
            // panel28
            // 
            this.panel28.BackColor = System.Drawing.Color.Transparent;
            this.panel28.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel28.BackgroundImage")));
            this.panel28.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel28.Location = new System.Drawing.Point(160, 80);
            this.panel28.Name = "panel28";
            this.panel28.Size = new System.Drawing.Size(80, 80);
            this.panel28.TabIndex = 10;
            this.panel28.Tag = "black";
            this.panel28.Click += new System.EventHandler(this.panel25_Click);
            // 
            // panel15
            // 
            this.panel15.BackColor = System.Drawing.Color.Transparent;
            this.panel15.BackgroundImage = global::Shahmati.Properties.Resources.король;
            this.panel15.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel15.Location = new System.Drawing.Point(320, 560);
            this.panel15.Name = "panel15";
            this.panel15.Size = new System.Drawing.Size(80, 80);
            this.panel15.TabIndex = 4;
            this.panel15.Tag = "white";
            this.panel15.Click += new System.EventHandler(this.panel15_Click);
            // 
            // panel29
            // 
            this.panel29.BackColor = System.Drawing.Color.Transparent;
            this.panel29.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel29.BackgroundImage")));
            this.panel29.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel29.Location = new System.Drawing.Point(400, 80);
            this.panel29.Name = "panel29";
            this.panel29.Size = new System.Drawing.Size(80, 80);
            this.panel29.TabIndex = 13;
            this.panel29.Tag = "black";
            this.panel29.Click += new System.EventHandler(this.panel25_Click);
            // 
            // panel24
            // 
            this.panel24.BackColor = System.Drawing.Color.Transparent;
            this.panel24.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel24.BackgroundImage")));
            this.panel24.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel24.Location = new System.Drawing.Point(0, 0);
            this.panel24.Name = "panel24";
            this.panel24.Size = new System.Drawing.Size(80, 80);
            this.panel24.TabIndex = 6;
            this.panel24.Tag = "black";
            this.panel24.Click += new System.EventHandler(this.panel9_Click);
            // 
            // panel30
            // 
            this.panel30.BackColor = System.Drawing.Color.Transparent;
            this.panel30.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel30.BackgroundImage")));
            this.panel30.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel30.Location = new System.Drawing.Point(80, 80);
            this.panel30.Name = "panel30";
            this.panel30.Size = new System.Drawing.Size(80, 80);
            this.panel30.TabIndex = 9;
            this.panel30.Tag = "black";
            this.panel30.Click += new System.EventHandler(this.panel25_Click);
            // 
            // panel18
            // 
            this.panel18.BackColor = System.Drawing.Color.Transparent;
            this.panel18.BackgroundImage = global::Shahmati.Properties.Resources.Король2;
            this.panel18.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel18.Location = new System.Drawing.Point(320, 0);
            this.panel18.Name = "panel18";
            this.panel18.Size = new System.Drawing.Size(80, 80);
            this.panel18.TabIndex = 11;
            this.panel18.Tag = "black";
            this.panel18.Click += new System.EventHandler(this.panel15_Click);
            // 
            // panel31
            // 
            this.panel31.BackColor = System.Drawing.Color.Transparent;
            this.panel31.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel31.BackgroundImage")));
            this.panel31.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel31.Location = new System.Drawing.Point(320, 80);
            this.panel31.Name = "panel31";
            this.panel31.Size = new System.Drawing.Size(80, 80);
            this.panel31.TabIndex = 12;
            this.panel31.Tag = "black";
            this.panel31.Click += new System.EventHandler(this.panel25_Click);
            // 
            // panel14
            // 
            this.panel14.BackColor = System.Drawing.Color.Transparent;
            this.panel14.BackgroundImage = global::Shahmati.Properties.Resources.слон;
            this.panel14.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel14.Location = new System.Drawing.Point(400, 560);
            this.panel14.Name = "panel14";
            this.panel14.Size = new System.Drawing.Size(80, 80);
            this.panel14.TabIndex = 4;
            this.panel14.Tag = "white";
            this.panel14.Click += new System.EventHandler(this.panel13_Click);
            // 
            // panel32
            // 
            this.panel32.BackColor = System.Drawing.Color.Transparent;
            this.panel32.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel32.BackgroundImage")));
            this.panel32.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel32.Location = new System.Drawing.Point(0, 80);
            this.panel32.Name = "panel32";
            this.panel32.Size = new System.Drawing.Size(80, 80);
            this.panel32.TabIndex = 8;
            this.panel32.Tag = "black";
            this.panel32.Click += new System.EventHandler(this.panel25_Click);
            // 
            // panel23
            // 
            this.panel23.BackColor = System.Drawing.Color.Transparent;
            this.panel23.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel23.BackgroundImage")));
            this.panel23.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel23.Location = new System.Drawing.Point(560, 0);
            this.panel23.Name = "panel23";
            this.panel23.Size = new System.Drawing.Size(80, 80);
            this.panel23.TabIndex = 8;
            this.panel23.Tag = "black";
            this.panel23.Click += new System.EventHandler(this.panel9_Click);
            // 
            // panel13
            // 
            this.panel13.BackColor = System.Drawing.Color.Transparent;
            this.panel13.BackgroundImage = global::Shahmati.Properties.Resources.слон;
            this.panel13.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel13.Location = new System.Drawing.Point(160, 560);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(80, 80);
            this.panel13.TabIndex = 3;
            this.panel13.Tag = "white";
            this.panel13.Click += new System.EventHandler(this.panel13_Click);
            // 
            // panel22
            // 
            this.panel22.BackColor = System.Drawing.Color.Transparent;
            this.panel22.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel22.BackgroundImage")));
            this.panel22.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel22.Location = new System.Drawing.Point(80, 0);
            this.panel22.Name = "panel22";
            this.panel22.Size = new System.Drawing.Size(80, 80);
            this.panel22.TabIndex = 7;
            this.panel22.Tag = "black";
            this.panel22.Click += new System.EventHandler(this.panel11_Click);
            // 
            // panel12
            // 
            this.panel12.BackColor = System.Drawing.Color.Transparent;
            this.panel12.BackgroundImage = global::Shahmati.Properties.Resources.конь;
            this.panel12.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel12.Location = new System.Drawing.Point(480, 560);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(80, 80);
            this.panel12.TabIndex = 3;
            this.panel12.Tag = "white";
            this.panel12.Click += new System.EventHandler(this.panel11_Click);
            // 
            // panel19
            // 
            this.panel19.BackColor = System.Drawing.Color.Transparent;
            this.panel19.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel19.BackgroundImage")));
            this.panel19.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel19.Location = new System.Drawing.Point(400, 0);
            this.panel19.Name = "panel19";
            this.panel19.Size = new System.Drawing.Size(80, 80);
            this.panel19.TabIndex = 12;
            this.panel19.Tag = "black";
            this.panel19.Click += new System.EventHandler(this.panel13_Click);
            // 
            // panel11
            // 
            this.panel11.BackColor = System.Drawing.Color.Transparent;
            this.panel11.BackgroundImage = global::Shahmati.Properties.Resources.конь;
            this.panel11.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel11.Location = new System.Drawing.Point(80, 560);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(80, 80);
            this.panel11.TabIndex = 2;
            this.panel11.Tag = "white";
            this.panel11.Click += new System.EventHandler(this.panel11_Click);
            // 
            // panel21
            // 
            this.panel21.BackColor = System.Drawing.Color.Transparent;
            this.panel21.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel21.BackgroundImage")));
            this.panel21.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel21.Location = new System.Drawing.Point(480, 0);
            this.panel21.Name = "panel21";
            this.panel21.Size = new System.Drawing.Size(80, 80);
            this.panel21.TabIndex = 10;
            this.panel21.Tag = "black";
            this.panel21.Click += new System.EventHandler(this.panel11_Click);
            // 
            // panel10
            // 
            this.panel10.BackColor = System.Drawing.Color.Transparent;
            this.panel10.BackgroundImage = global::Shahmati.Properties.Resources.ладья;
            this.panel10.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel10.Location = new System.Drawing.Point(560, 560);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(80, 80);
            this.panel10.TabIndex = 2;
            this.panel10.Tag = "white";
            this.panel10.Click += new System.EventHandler(this.panel9_Click);
            // 
            // panel20
            // 
            this.panel20.BackColor = System.Drawing.Color.Transparent;
            this.panel20.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel20.BackgroundImage")));
            this.panel20.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel20.Location = new System.Drawing.Point(160, 0);
            this.panel20.Name = "panel20";
            this.panel20.Size = new System.Drawing.Size(80, 80);
            this.panel20.TabIndex = 9;
            this.panel20.Tag = "black";
            this.panel20.Click += new System.EventHandler(this.panel13_Click);
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.Color.Transparent;
            this.panel9.BackgroundImage = global::Shahmati.Properties.Resources.ладья;
            this.panel9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel9.Location = new System.Drawing.Point(0, 560);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(80, 80);
            this.panel9.TabIndex = 1;
            this.panel9.Tag = "white";
            this.panel9.Click += new System.EventHandler(this.panel9_Click);
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.Transparent;
            this.panel5.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel5.BackgroundImage")));
            this.panel5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel5.Location = new System.Drawing.Point(560, 480);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(80, 80);
            this.panel5.TabIndex = 7;
            this.panel5.Tag = "white";
            this.panel5.Click += new System.EventHandler(this.panel1_Click);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Transparent;
            this.panel3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel3.BackgroundImage")));
            this.panel3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel3.Location = new System.Drawing.Point(240, 480);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(80, 80);
            this.panel3.TabIndex = 3;
            this.panel3.Tag = "white";
            this.panel3.Click += new System.EventHandler(this.panel1_Click);
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.Transparent;
            this.panel6.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel6.BackgroundImage")));
            this.panel6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel6.Location = new System.Drawing.Point(480, 480);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(80, 80);
            this.panel6.TabIndex = 6;
            this.panel6.Tag = "white";
            this.panel6.Click += new System.EventHandler(this.panel1_Click);
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.Transparent;
            this.panel4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel4.BackgroundImage")));
            this.panel4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel4.Location = new System.Drawing.Point(160, 480);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(80, 80);
            this.panel4.TabIndex = 2;
            this.panel4.Tag = "white";
            this.panel4.Click += new System.EventHandler(this.panel1_Click);
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.Transparent;
            this.panel7.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel7.BackgroundImage")));
            this.panel7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel7.Location = new System.Drawing.Point(400, 480);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(80, 80);
            this.panel7.TabIndex = 5;
            this.panel7.Tag = "white";
            this.panel7.Click += new System.EventHandler(this.panel1_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Transparent;
            this.panel2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel2.BackgroundImage")));
            this.panel2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel2.Location = new System.Drawing.Point(80, 480);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(80, 80);
            this.panel2.TabIndex = 1;
            this.panel2.Tag = "white";
            this.panel2.Click += new System.EventHandler(this.panel1_Click);
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.Transparent;
            this.panel8.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel8.BackgroundImage")));
            this.panel8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel8.Location = new System.Drawing.Point(320, 480);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(80, 80);
            this.panel8.TabIndex = 4;
            this.panel8.Tag = "white";
            this.panel8.Click += new System.EventHandler(this.panel1_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Transparent;
            this.panel1.BackgroundImage = global::Shahmati.Properties.Resources.пешка;
            this.panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel1.Location = new System.Drawing.Point(0, 480);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(80, 80);
            this.panel1.TabIndex = 0;
            this.panel1.Tag = "white";
            this.panel1.Click += new System.EventHandler(this.panel1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(659, 656);
            this.Controls.Add(this.BackPanel);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Form1";
            this.Text = "Form1";
            this.BackPanel.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel BackPanel;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.Panel panel14;
        private System.Windows.Forms.Panel panel15;
        private System.Windows.Forms.Panel panel16;
        private System.Windows.Forms.Panel panel25;
        private System.Windows.Forms.Panel panel17;
        private System.Windows.Forms.Panel panel26;
        private System.Windows.Forms.Panel panel27;
        private System.Windows.Forms.Panel panel28;
        private System.Windows.Forms.Panel panel29;
        private System.Windows.Forms.Panel panel24;
        private System.Windows.Forms.Panel panel30;
        private System.Windows.Forms.Panel panel18;
        private System.Windows.Forms.Panel panel31;
        private System.Windows.Forms.Panel panel32;
        private System.Windows.Forms.Panel panel23;
        private System.Windows.Forms.Panel panel22;
        private System.Windows.Forms.Panel panel19;
        private System.Windows.Forms.Panel panel21;
        private System.Windows.Forms.Panel panel20;
    }
}

