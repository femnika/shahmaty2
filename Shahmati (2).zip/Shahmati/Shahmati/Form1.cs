﻿using System;

using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Shahmati
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            Start();
        }

        private int xObj = 0;//Текущее положение фигуры
        private int yObj = 0;

        private Point[] ToLoc = new Point[640];//Куда перейдет фигура

        private bool Selected = false;//Если выбрана фигура

        public Panel globPanel = null;//Глобальная панель

        public string hod = "white";

        private void Start()
        {
            hide("white");
            Restart();
        }

        private void hide(string hod)
        {
            foreach (Control childControl in BackPanel.Controls)
            {
                if (childControl.Tag.ToString() != hod)
                {
                    childControl.Enabled = false;
                }
                else
                    childControl.Enabled = true;
            }
        }

        public bool Search(Point func, bool peshka = false, bool forward = false)
        {
            if (!peshka)
            {
                if (BackPanel.GetChildAtPoint(new Point((func.X - 1) * 80, (func.Y - 1) * 80)) == null || BackPanel.GetChildAtPoint(new Point((func.X - 1) * 80, (func.Y - 1) * 80)).Tag.ToString() != hod)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            else
            {
                if (forward)
                {
                    if (BackPanel.GetChildAtPoint(new Point((func.X - 1) * 80, (func.Y - 1) * 80)) == null)
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                }
                else
                {
                    if (BackPanel.GetChildAtPoint(new Point((func.X - 1) * 80, (func.Y - 1) * 80)) != null)
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                }
            }
        }




        private void Pathfinding(string face, string type, Panel panel)
        {
            if (globPanel == panel)//второе нажатие по той же фигуре
                Selected = !Selected;
            else//нажатие по другой фигуре
                Selected = true;
            for (int i = 0; i < ToLoc.Length; i++)//ощистка массива с координатами
            {
                ToLoc[i] = new Point(0,0);
            }
            
            globPanel = panel;

            if (Selected)
            {
                xObj = globPanel.Location.X / 80 + 1;
                yObj = globPanel.Location.Y / 80 + 1;
                globPanel.BackColor = Color.White;

                if( type == "peshka")
                {
                    if( face == "you")
                    {
                        

                        if (yObj == 7)
                        {
                            if(Search(new Point(xObj, yObj - 1), true, true))
                            {
                                ToLoc[0] = new Point(xObj, yObj - 1);
                                if (Search(new Point(xObj - 1, yObj - 1), true))
                                    ToLoc[1] = new Point(xObj - 1, yObj - 1);
                                if (Search(new Point(xObj + 1, yObj - 1), true))
                                    ToLoc[2] = new Point(xObj + 1, yObj - 1);
                            }
                            else
                            {
                                if (Search(new Point(xObj - 1, yObj - 1), true))
                                    ToLoc[0] = new Point(xObj - 1, yObj - 1);
                                if (Search(new Point(xObj + 1, yObj - 1), true))
                                    ToLoc[1] = new Point(xObj + 1, yObj - 1);
                            }
                            if (Search(new Point(xObj, yObj - 2), true, true))
                            {
                                ToLoc[1] = new Point(xObj, yObj - 2);
                                if (Search(new Point(xObj - 1, yObj - 1), true))
                                    ToLoc[2] = new Point(xObj - 1, yObj - 1);
                                if (Search(new Point(xObj + 1, yObj - 1), true))
                                    ToLoc[3] = new Point(xObj + 1, yObj - 1);
                            }
                            else
                            {
                                if (Search(new Point(xObj - 1, yObj - 1), true))
                                    ToLoc[0] = new Point(xObj - 1, yObj - 1);
                                if (Search(new Point(xObj + 1, yObj - 1), true))
                                    ToLoc[1] = new Point(xObj + 1, yObj - 1);
                            }

                            
                        }
                        else
                        {
                            if (Search(new Point(xObj, yObj - 1), true, true))
                            {
                                ToLoc[0] = new Point(xObj, yObj - 1);
                                if (Search(new Point(xObj - 1, yObj - 1), true))
                                    ToLoc[1] = new Point(xObj - 1, yObj - 1);
                                if (Search(new Point(xObj + 1, yObj - 1), true))
                                    ToLoc[2] = new Point(xObj + 1, yObj - 1);
                            }
                            else
                            {
                                if (Search(new Point(xObj - 1, yObj - 1), true))
                                    ToLoc[0] = new Point(xObj - 1, yObj - 1);
                                if (Search(new Point(xObj + 1, yObj - 1), true))
                                    ToLoc[1] = new Point(xObj + 1, yObj - 1);
                            }
                        }
                            
                    }
                    if (face == "he")
                    {
                        
                        if (yObj == 2)
                        {
                            if (Search(new Point(xObj, yObj + 1), true, true))
                            {
                                ToLoc[0] = new Point(xObj, yObj + 1);
                                if (Search(new Point(xObj - 1, yObj + 1), true))
                                    ToLoc[1] = new Point(xObj - 1, yObj + 1);
                                if (Search(new Point(xObj + 1, yObj + 1), true))
                                    ToLoc[2] = new Point(xObj + 1, yObj + 1);
                            }
                            else
                            {
                                if (Search(new Point(xObj - 1, yObj + 1), true))
                                    ToLoc[0] = new Point(xObj - 1, yObj + 1);
                                if (Search(new Point(xObj + 1, yObj + 1), true))
                                    ToLoc[1] = new Point(xObj + 1, yObj + 1);
                            }
                            if (Search(new Point(xObj, yObj + 2), true, true))
                            {
                                ToLoc[1] = new Point(xObj, yObj + 2);
                                if (Search(new Point(xObj - 1, yObj + 1), true))
                                    ToLoc[2] = new Point(xObj - 1, yObj + 1);
                                if (Search(new Point(xObj + 1, yObj + 1), true))
                                    ToLoc[3] = new Point(xObj + 1, yObj + 1);
                            }
                            else
                            {
                                if (Search(new Point(xObj - 1, yObj + 1), true))
                                    ToLoc[0] = new Point(xObj - 1, yObj + 1);
                                if (Search(new Point(xObj + 1, yObj + 1), true))
                                    ToLoc[1] = new Point(xObj + 1, yObj + 1);
                            }
                        }
                        else
                        {
                            if (Search(new Point(xObj, yObj + 1), true, true))
                            {
                                ToLoc[0] = new Point(xObj, yObj + 1);
                                if (Search(new Point(xObj - 1, yObj + 1), true))
                                    ToLoc[1] = new Point(xObj - 1, yObj + 1);
                                if (Search(new Point(xObj + 1, yObj + 1), true))
                                    ToLoc[2] = new Point(xObj + 1, yObj + 1);
                            }
                            else
                            {
                                if (Search(new Point(xObj - 1, yObj + 1), true))
                                    ToLoc[0] = new Point(xObj - 1, yObj + 1);
                                if (Search(new Point(xObj + 1, yObj + 1), true))
                                    ToLoc[1] = new Point(xObj + 1, yObj + 1);
                            }
                        }
                    }
                }
                if( type == "ladya")
                {
                    if(face == "you" || face == "he")
                    {
                        int itration = 0;
                        for(int i = yObj-1; i > 0; i--)//Up
                        {
                            itration++;
                            if (Search(new Point(xObj, i)))
                                ToLoc[itration] = new Point(xObj, i);
                            else
                                break;
                        }
                        for (int i = xObj + 1; i < 9; i++)//Right
                        {
                            itration++;
                            if (Search(new Point(i, yObj)))
                                ToLoc[itration] = new Point(i, yObj);
                            else
                                break;
                        }
                        for (int i = yObj + 1; i < 9; i++)//Down
                        {
                            itration++;
                            if (Search(new Point(xObj, i)))
                                ToLoc[itration] = new Point(xObj, i);
                            else
                                break;
                        }
                        for (int i = xObj - 1; i > 0; i--)//Left
                        {
                            itration++;
                            if (Search(new Point(i, yObj)))
                                ToLoc[itration] = new Point(i, yObj);
                            else
                                break;
                        }
                    }
                }
                if(type == "kon")
                {
                    if (face == "you" || face == "he")
                    {
                        ToLoc[0] = new Point(xObj + 1, yObj + 2);
                        ToLoc[1] = new Point(xObj - 1, yObj + 2);
                        ToLoc[2] = new Point(xObj + 1, yObj - 2);
                        ToLoc[3] = new Point(xObj - 1, yObj - 2);

                        ToLoc[4] = new Point(xObj + 2, yObj + 1);
                        ToLoc[5] = new Point(xObj + 2, yObj - 1);
                        ToLoc[6] = new Point(xObj - 2, yObj + 1);
                        ToLoc[7] = new Point(xObj - 2, yObj - 1);
                    }
                }
                if(type == "slon")
                {
                    if (face == "you" || face == "he")
                    {
                        int itration = 0;
                        for (int i = 1; i < Math.Min((byte)xObj, (byte)yObj); i++)//Up-Left
                        {
                            itration++;
                            if (Search(new Point(xObj - i, yObj - i)))
                                ToLoc[itration] = new Point(xObj - i, yObj - i);
                            else
                                break;
                        }
                        for (int i = 1; i < Math.Min((byte)(8 - xObj + 1), (byte)yObj) + 1; i++)//Up-Right
                        {
                            itration++;
                            if (Search(new Point(xObj + i, yObj - i)))
                                ToLoc[itration] = new Point(xObj + i, yObj - i);
                            else
                                break;
                        }
                        for (int i = 1; i < Math.Min((byte)(8 - xObj), (byte)(8-yObj))+1; i++)//Down-Right
                        {
                            itration++;
                            if (Search(new Point(xObj + i, yObj + i)))
                                ToLoc[itration] = new Point(xObj + i, yObj + i);
                            else
                                break;
                        }
                        for (int i = 1; i < Math.Min((byte)xObj, (byte)(8 - yObj)) + 1; i++)//Down-Left
                        {
                            itration++;
                            if (Search(new Point(xObj - i, yObj + i)))
                                ToLoc[itration] = new Point(xObj - i, yObj + i);
                            else
                                break;
                        }
                    }
                }
                if(type == "korol")
                {
                    if (face == "you" || face == "he")
                    {
                        ToLoc[0] = new Point(xObj - 1, yObj + 1);
                        ToLoc[1] = new Point(xObj, yObj + 1);
                        ToLoc[2] = new Point(xObj + 1, yObj + 1);

                        ToLoc[3] = new Point(xObj - 1, yObj);
                        ToLoc[4] = new Point(xObj + 1, yObj);

                        ToLoc[5] = new Point(xObj - 1, yObj - 1);
                        ToLoc[6] = new Point(xObj, yObj - 1);
                        ToLoc[7] = new Point(xObj + 1, yObj - 1);
                    }
                }
                if (type == "ferz")
                {
                    if (face == "you" || face == "he")
                    {
                        int itration = 0;
                        for (int i = yObj - 1; i > 0; i--)//Up
                        {
                            itration++;
                            if (Search(new Point(xObj, i)))
                                ToLoc[itration] = new Point(xObj, i);
                            else
                                break;
                        }
                        for (int i = xObj + 1; i < 9; i++)//Right
                        {
                            itration++;
                            if (Search(new Point(i, yObj)))
                                ToLoc[itration] = new Point(i, yObj);
                            else
                                break;
                        }
                        for (int i = yObj + 1; i < 9; i++)//Down
                        {
                            itration++;
                            if (Search(new Point(xObj, i)))
                                ToLoc[itration] = new Point(xObj, i);
                            else
                                break;
                        }
                        for (int i = xObj - 1; i > 0; i--)//Left
                        {
                            itration++;
                            if (Search(new Point(i, yObj)))
                                ToLoc[itration] = new Point(i, yObj);
                            else
                                break;
                        }
                        for (int i = 1; i < Math.Min((byte)xObj, (byte)yObj); i++)//Up-Left
                        {
                            itration++;
                            if (Search(new Point(xObj - i, yObj - i)))
                                ToLoc[itration] = new Point(xObj - i, yObj - i);
                            else
                                break;
                        }
                        for (int i = 1; i < Math.Min((byte)(8 - xObj), (byte)yObj) + 1; i++)//Up-Right
                        {
                            itration++;
                            if (Search(new Point(xObj + i, yObj - i)))
                                ToLoc[itration] = new Point(xObj + i, yObj - i);
                            else
                                break;
                        }
                        for (int i = 1; i < Math.Min((byte)(8 - xObj), (byte)(8 - yObj)) + 1; i++)//Down-Right
                        {
                            itration++;
                            if (Search(new Point(xObj + i, yObj + i)))
                                ToLoc[itration] = new Point(xObj + i, yObj + i);
                            else
                                break;
                        }
                        for (int i = 1; i < Math.Min((byte)xObj, (byte)(8 - yObj)) + 1; i++)//Down-Left
                        {
                            itration++;
                            if (Search(new Point(xObj - i, yObj + i)))
                                ToLoc[itration] = new Point(xObj - i, yObj + i);
                            else
                                break;
                        }
                    }
                }
            }
            else
            {
                globPanel.BackColor = Color.Transparent;
            }
        }
        private void BackPanel_MouseClick(object sender, MouseEventArgs e)
        {
            int mX = (int)Math.Ceiling((double)e.X / 80);
            int mY = (int)Math.Ceiling((double)e.Y / 80);
            Point mLoc = new Point(mX, mY);

            if (Selected)
            {
                for (int i = 0; i < ToLoc.Length; i++)
                {
                    if (ToLoc[i] != null)
                    {
                        if (mLoc == ToLoc[i])
                        {
                            if (BackPanel.GetChildAtPoint(new Point((mX - 1) * 80, (mY - 1) * 80)) != null)
                            {
                                if (BackPanel.GetChildAtPoint(new Point((mX - 1) * 80, (mY - 1) * 80)).Name == "panel18")
                                {
                                    MessageBox.Show("Белые выиграли!");
                                    Restart();
                                    globPanel.BackColor = Color.Transparent;
                                    break;
                                }
                                if (BackPanel.GetChildAtPoint(new Point((mX - 1) * 80, (mY - 1) * 80)).Name == "panel15")
                                {
                                    MessageBox.Show("Черные выиграли!");
                                    Restart();
                                    globPanel.BackColor = Color.Transparent;
                                    break;
                                }
                                BackPanel.GetChildAtPoint(new Point((mX - 1) * 80, (mY - 1) * 80)).Visible = false;
                                BackPanel.GetChildAtPoint(new Point((mX - 1) * 80, (mY - 1) * 80)).Enabled = false;
                                globPanel.Location = new Point((mX - 1) * 80, (mY - 1) * 80);
                                globPanel.BackColor = Color.Transparent;
                            }
                            else
                            {
                                bool isPeshka = false;
                                for(int p = 1; p <= 8; p++)
                                {
                                    if (globPanel.Name == $"panel{i}")
                                        isPeshka = true;
                                }
                                for (int p = 25; p <= 32; p++)
                                {
                                    if (globPanel.Name == $"panel{i}")
                                        isPeshka = true;
                                }
                                if (!isPeshka) { }
                                    globPanel.Location = new Point((mX - 1) * 80, (mY - 1) * 80);
                                globPanel.BackColor = Color.Transparent;
                            }
                            Selected = false;
                            if (hod == "white")
                            {
                                hide("black");
                                hod = "black";
                            }
                            else if (hod == "black")
                            {
                                hide("white");
                                hod = "white";
                            }
                            break;
                        }
                    }
                    else
                        break;
                }
            }
        }
        private void Restart()
        {
            //
            foreach (Control childControl in BackPanel.Controls)
            {
                childControl.Enabled = true;
                childControl.Visible = true;
                if (childControl.Tag.ToString() != "white")
                    childControl.Enabled = false;
                else
                    childControl.Enabled = true;
            }
            //Пешки
            panel1.Location = new Point(0, 480);
            panel2.Location = new Point(80, 480);
            panel3.Location = new Point(160, 480);
            panel4.Location = new Point(240, 480);
            panel5.Location = new Point(320, 480);
            panel6.Location = new Point(400, 480);
            panel7.Location = new Point(480, 480);
            panel8.Location = new Point(560, 480);

            panel25.Location = new Point(0, 80);
            panel26.Location = new Point(80, 80);
            panel27.Location = new Point(160, 80);
            panel28.Location = new Point(240, 80);
            panel29.Location = new Point(320, 80);
            panel30.Location = new Point(400, 80);
            panel31.Location = new Point(480, 80);
            panel32.Location = new Point(560, 80);
            //Другие фигуры
            panel9.Location = new Point(0, 560);
            panel11.Location = new Point(80, 560);
            panel13.Location = new Point(160, 560);
            panel16.Location = new Point(240, 560);
            panel15.Location = new Point(320, 560);
            panel14.Location = new Point(400, 560);
            panel12.Location = new Point(480, 560);
            panel10.Location = new Point(560, 560);

            panel24.Location = new Point(0, 0);
            panel22.Location = new Point(80, 0);
            panel20.Location = new Point(160, 0);
            panel17.Location = new Point(240, 0);
            panel18.Location = new Point(320, 0);
            panel19.Location = new Point(400, 0);
            panel21.Location = new Point(480, 0);
            panel23.Location = new Point(560, 0);
        }

        private void panel1_Click(object sender, EventArgs e)
        {
            Pathfinding("you", "peshka", (Panel)sender);
        }

        private void panel25_Click(object sender, EventArgs e)
        {
            Pathfinding("he", "peshka", (Panel)sender);
        }

        private void panel9_Click(object sender, EventArgs e)
        {
            Pathfinding("you", "ladya", (Panel)sender);
        }

        private void panel11_Click(object sender, EventArgs e)
        {
            Pathfinding("you", "kon", (Panel)sender);
        }

        private void panel13_Click(object sender, EventArgs e)
        {
            Pathfinding("you", "slon", (Panel)sender);
        }

        private void panel15_Click(object sender, EventArgs e)
        {
            Pathfinding("you", "korol", (Panel)sender);
        }

        private void panel16_Click(object sender, EventArgs e)
        {
            Pathfinding("you", "ferz", (Panel)sender);
        }

    }
}
