﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Drawing;
using Shahmati;

namespace UnitTestProject1
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethodSearch()
        {
            int x = 0;
            int y = 0;
            bool peshka = false;
            bool forward = false;

            bool expected = true;
            Point point = new Point(x, y);
            Form1 form = new Form1();

            bool actual = form.Search(point, peshka, forward);
            Assert.AreEqual(expected, actual);

        }
    }
}
